<?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td><?php echo e($member->firstname); ?></td>a
		<td><?php echo e($member->lastname); ?></td>
		<td><a style="cursor:pointer;" class='btn btn-success edit' data-id='<?php echo e($member->id); ?>' data-first='<?php echo e($member->firstname); ?>' data-last='<?php echo e($member->lastname); ?>'><i class='fa fa-edit'></i> Edit</a> 
			<a style="cursor:pointer;" class='btn btn-danger delete' data-id='<?php echo e($member->id); ?>'><i class='fa fa-trash'></i> Delete</a>
		</td>
	</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>