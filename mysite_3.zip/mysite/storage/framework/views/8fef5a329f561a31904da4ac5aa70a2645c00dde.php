<?php $__env->startSection('content'); ?>
<h1 class"page-header text-center">Bootstrap Buttons</h1>
<div class="row">
	<div class="col-md-12">
		<h3>Buttons with Glyphicon</h3>
		<button class="btn btn-primary"><i class="fa fa-home"></i> Primary</button> 
		<button class="btn btn-success"><span class="glyphicon glyphicon-home"></span> Success</button>
		<button class="btn btn-info"><span class="glyphicon glyphicon-home"></span> Info</button>
		<button class="btn btn-warning"><span class="glyphicon glyphicon-home"></span> Warning</button>
		<button class="btn btn-danger"><span class="glyphicon glyphicon-home"></span> Danger</button>
	</div>
</div>
<div class="row">
	<div class="col-md-12">
		<a href="#myModal" data-toggle="modal" class="btn btn-primary">Open Modal</a>
	</div>

	<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Modal title</h4>
      </div>
      <div class="modal-body">
        ...
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary">Save changes</button>
      </div>
    </div>
  </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>