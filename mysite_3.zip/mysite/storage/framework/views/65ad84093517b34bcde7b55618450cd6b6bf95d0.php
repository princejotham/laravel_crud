<div class="jumbotron text-center">
	<div class="container">
		<h1>Welcome to MySite</h1>
		<p class="lead">This is a Laravel Powered Site. This site uses Laravel version 5.5.</p>
	</div>
</div>