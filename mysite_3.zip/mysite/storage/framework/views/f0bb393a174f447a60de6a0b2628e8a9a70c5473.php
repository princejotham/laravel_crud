<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Setting up Bootstrap in Laravel</title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="/css/app.css">
</head>
<body>
<?php echo $__env->make('navbar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
	<?php if(Request::is('/')): ?>
		<?php echo $__env->make('showcase', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php endif; ?>
	<?php echo $__env->yieldContent('content'); ?>
</div>
<script type="text/javascript" src="<?php echo e(asset('/js/bootstrap.min.js')); ?>"></script>
</body>
</html>