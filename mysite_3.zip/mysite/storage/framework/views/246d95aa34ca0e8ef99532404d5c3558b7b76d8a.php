<?php $__env->startSection('content'); ?>
<h1 class"page-header text-center">Bootstrap Buttons</h1>
<div class="row">
	<div class="col-md-12">
		<h3>Buttons with Glyphicon</h3>
		<button class="btn btn-primary"><span class="glyphicon glyphicon-home"></span> Primary</button> 
		<button class="btn btn-success"><span class="glyphicon glyphicon-home"></span> Success</button>
		<button class="btn btn-info"><span class="glyphicon glyphicon-home"></span> Info</button>
		<button class="btn btn-warning"><span class="glyphicon glyphicon-home"></span> Warning</button>
		<button class="btn btn-danger"><span class="glyphicon glyphicon-home"></span> Danger</button>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>